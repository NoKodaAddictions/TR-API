Time API Wrapper Using Python and WorldTimeApi.org

Who will ever use this s**t other than me?

Part of the Northwest Notes Project